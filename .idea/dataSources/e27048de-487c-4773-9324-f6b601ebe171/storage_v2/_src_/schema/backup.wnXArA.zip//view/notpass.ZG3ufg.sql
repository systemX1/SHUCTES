create definer = root@localhost view notpass as
select `backup`.`stu`.`id`       AS `id`,
       `backup`.`stu`.`name`     AS `name`,
       `backup`.`stu`.`sex`      AS `sex`,
       `backup`.`stu`.`phone`    AS `phone`,
       `backup`.`subject`.`name` AS `name`,
       `backup`.`course`.`grade` AS `grade`
from ((`backup`.`stu` join `backup`.`course`)
         join `backup`.`subject`)
where ((`backup`.`course`.`grade` < 60) and (`backup`.`course`.`stu_id` = `backup`.`stu`.`id`) and
       (`backup`.`course`.`subj_id` = `backup`.`subject`.`id`) and `backup`.`stu`.`dept_id` in
                                                                   (select `backup`.`dept`.`id`
                                                                    from `backup`.`dept`
                                                                    where (`backup`.`dept`.`name` = '计算机学院')))
group by `backup`.`course`.`stu_id`;


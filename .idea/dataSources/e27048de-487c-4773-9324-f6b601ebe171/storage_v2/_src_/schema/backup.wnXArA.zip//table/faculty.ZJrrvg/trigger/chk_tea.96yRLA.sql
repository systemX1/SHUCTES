create definer = root@localhost trigger chk_tea
    before insert
    on faculty
    for each row
BEGIN
IF (NEW.sex <> '男') AND (NEW.sex <> '女')
AND ( (NEW.sex = '男') OR (NEW.dept_id <> '01') ) THEN
SIGNAL SQLSTATE '45000'   
SET MESSAGE_TEXT = 'Invaild data';
END IF;
END;

